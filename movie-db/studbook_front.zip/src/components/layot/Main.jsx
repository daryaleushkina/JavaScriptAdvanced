import React from 'react';
import {Movies} from "../Movies";
import {Preloader} from "../Preloader"
import {Search} from "../Search";
class Main extends React.Component {
    state = {
        movies:[],
        loading: true,
    }
    componentDidMount() {
        console.log(process.env);
        fetch(`https://www.omdbapi.com/?apikey=b98de2fc&s=computer`)
            .then((response) => response.json())
            .then((data) =>
                this.setState({ movies: data.Search, loading: false })
            )
            .catch((err) => {
                console.error(err);
                this.setState({ loading: false });
            });
    }
    searchMovies = (s,type='all') => {
        if (!s.length)
            s = 'computer'
        fetch(`http://www.omdbapi.com/?apikey=b98de2fc&s=${s}${
            type !== 'all' ? `&type=${type}` : ''}`)
            .then(response => response.json())
            .then(data => this.setState({movies:data.Search}))

    }

    render() {
        const { movies, loading } = this.state;

        return (
            <main className='container content'>
                <Search searchMovies={this.searchMovies} />
                {loading ? <Preloader /> : <Movies movies={movies} />}
            </main>
        );
    }


}

export {Main}